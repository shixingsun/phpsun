<?php
include 'Config.php';
include_once 'Request/V20170525/SingleCallByTtsRequest.php';
include_once 'Request/V20170525/SingleCallByVoiceRequest.php';
//文件编码格式UTF-8
function singleCallByVoice() {
    
    //此处需要替换成自己的AK信息
    $accessKeyId = "yourAccessKeyId";
    $accessKeySecret = "yourAccessKeySecret";
    
    //流量API产品名
    $product = "Dyvmsapi";
    //流量API产品域名
    $domain = "dyvmsapi.aliyuncs.com";
    //暂时不支持多Region
    $region = "cn-hangzhou";
    
    //初始化访问的acsCleint
    $profile = DefaultProfile::getProfile($region, $accessKeyId, $accessKeySecret);
    DefaultProfile::addEndpoint("cn-hangzhou", "cn-hangzhou", $product, $domain);
    $acsClient= new DefaultAcsClient($profile);
    
    $request = new Dyvmsapi\Request\V20170525\SingleCallByVoiceRequest();
    //必填-被叫显号
    $request->setCalledShowNumber("400100000");
    //必填-被叫号码
    $request->setCalledNumber("13700000000");
    //必填-语音文件Code
    $request->setVoiceCode("c2e99ebc-2d4c-4e78-8d2a-afbb06cf6216.wav");
    //选填-外呼流水号
    $request->setOutId("1234");
    
    //发起访问请求
    $acsResponse = $acsClient->getAcsResponse($request);
    
}

function singleCallByTts() {
    
    $accessKeyId = "yourAccessKeyId";
    $accessKeySecret = "yourAccessKeySecret";
    $product = "Dyvmsapi";
    $domain = "dyvmsapi.aliyuncs.com";
    $region = "cn-hangzhou";
    
    //初始化访问的acsCleint
    $profile = DefaultProfile::getProfile($region, $accessKeyId, $accessKeySecret);
    DefaultProfile::addEndpoint("cn-hangzhou", "cn-hangzhou", $product, $domain);
    $acsClient= new DefaultAcsClient($profile);
    
    $request = new Dyvmsapi\Request\V20170525\SingleCallByTtsRequest();
    //必填-被叫显号
    $request->setCalledShowNumber("4001112222");
    //必填-被叫号码
    $request->setCalledNumber("13700000000");
    //必填-Tts模板Code
    $request->setTtsCode("TTS_10001");
    //选填-Tts模板中的变量替换JSON,假如Tts模板中存在变量，则此处必填
    $request->setTtsParam("{\"AckNum\":\"123456\"}");
    //选填-外呼流水号
    $request->setOutId("1234");
    
    //发起访问请求
    $acsResponse = $acsClient->getAcsResponse($request);
    
}

singleCallByVoice();
singleCallByTts();
?>